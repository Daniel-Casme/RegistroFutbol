/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.registrofutbol;
import java.time.LocalDate;

/**
 *
 * @author Daniel CasMe
 */

// Registro, búsqueda y reutilización de clientes existentes.

public class Clientes {
    private int codigo = 1;
    private String nombre;
    private String telefono;
    private String correoElectronico;
    private LocalDate fechaRegistro;
    
    
    public Clientes(int codigo, String nombre, String telefono, String correoElectronico){
        this.codigo = codigo;
        this.nombre = nombre;
        this.telefono = telefono;
        this.correoElectronico = correoElectronico;
        this.fechaRegistro = LocalDate.now();
    }
    
    public int getCodigo(){
        return codigo;
    }
    
    public String getNombre(){
        return nombre;
    }
    
    public String getTelefono(){
        return telefono;
    }
    
    public String getCorreoElectronico(){
        return correoElectronico;
    }
    
    public LocalDate getFechaRegistro(){
        return fechaRegistro;
    }
}   
