/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.registrofutbol;
import java.util.Scanner;
import java.time.LocalTime;
/**
 *
 * @author Daniel CasMe
 */
public class RegistroFutbol {
    static Scanner sc = new Scanner(System.in);
    static GestorClientes main = new GestorClientes();
    static GestorCanchas canchasMain = new GestorCanchas();

    public static void main(String[] args) {
        //private String cambioCodigo;
        //private String cambioNombre;
        //private String cambioTipo;
        //private int cambioCapacidad;
        //private int cambioConfiguracionTarifaria;
        //private String cambioEstado;
        //private double cambioHoraApertura;
        //private double cambioHoraCierre;
        
        int opcion = -1;
        System.out.print("1) Registrar Cliente."
                + "\n2) Registrar Cancha." + "\nOpcion> ");
        opcion = sc.nextInt();
        sc.nextLine();
        switch(opcion){
            case 1:
                ejecutorClientes();
                break;
            case 2:
                ejecutorCanchas();
                break;
        }
                
    }
    
    public static void ejecutorClientes(){
        System.out.print("Ingresar Nombre y Apellido: ");
        String nombre = sc.nextLine();

        System.out.print("Ingresar Teléfono (0000-0000): ");
        String telefono = sc.nextLine();

        System.out.print("Ingresar correo electrónico (Enter: opcional): ");
        String correoElectronico = sc.nextLine();
        
        main.nuevoUsuario(nombre, telefono, correoElectronico);
        main.mostrarClientes();
    }
    
    public static void ejecutorCanchas(){
        System.out.print("Ingresar código (CA01: ");
        String codigo = sc.nextLine();

        System.out.print("Ingresar nombre: ");
        String nombre = sc.nextLine();

        System.out.print("Ingresar tipo: ");
        String tipo = sc.nextLine();

        System.out.print("Ingresar capacidad: ");
        int capacidad = sc.nextInt();
        sc.nextLine();

        System.out.print("Ingresar configuración tarifaria: ");
        int configuracionTarifaria = sc.nextInt();
        sc.nextLine();

        System.out.print("Ingresar estado: ");
        String estado = sc.nextLine();
        
        System.out.println("Ingresar hora de apertura (hh:mm): ");
        LocalTime HoraApertura = LocalTime.parse(sc.nextLine());
        
        System.out.println("Ingresar hora de cierre (hh:mm): ");
        LocalTime HoraCierre = LocalTime.parse(sc.nextLine());
        
        canchasMain.guardarCancha(codigo, nombre, tipo, capacidad, configuracionTarifaria, estado, HoraApertura, HoraCierre);
        canchasMain.mostrarCanchas();
    }
}
