/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.registrofutbol;

/**
 *
 * @author Daniel CasMe
 */

//Creación, validación, estados, cancelación e historial.
public class Reservas {
    
}
