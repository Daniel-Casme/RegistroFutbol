/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.registrofutbol;
import java.time.LocalTime;
/**
 *
 * @author Daniel CasMe
 */

//Administración de canchas, tipos, horarios y estados.
public class Canchas {
    private String codigo;
    private String nombre;
    private String tipo;
    private int capacidad;
    private int configuracionTarifaria;
    private String estado;
    private LocalTime horaApertura;
    private LocalTime horaCierre;
    
    public Canchas(String codigo, String nombre, String tipo, 
            int capacidad, int configuracionTarifaria, 
            String estado, LocalTime horaApertura, LocalTime horaCierre){
        
        this.codigo = codigo;
        this.nombre = nombre;
        this.tipo = tipo;
        this.capacidad = capacidad;
        this.configuracionTarifaria = configuracionTarifaria;
        this.estado = estado;
        this.horaApertura = horaApertura;
        this.horaCierre = horaCierre;
    }
    
    public String getCodigo(){
        return codigo;
    }
    
    public String getNombre(){
        return nombre;
    }
    
    public String getTipo(){
        return tipo;
    }
    
    public int getCapacidad(){
        return capacidad;
    }
    
    public int getConfiguracionTarifaria(){
        return configuracionTarifaria;
    }
    
    public String getEstado(){
        return estado;
    }
    
    public LocalTime getHoraApertura(){
        return horaApertura;
    }
    
    public LocalTime getHoraCierre(){
        return horaCierre;
    }
}
