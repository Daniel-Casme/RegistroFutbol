/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.registrofutbol;

import java.util.ArrayList;
/**
 *
 * @author Daniel CasMe
 */
public class GestorClientes {
    ArrayList<Clientes> usuario = new ArrayList<>();
    int codigo = 1;
    public void nuevoUsuario( String nombre, String telefono, String correoElectronico) {
        if (!nombre.isBlank() && !telefono.isBlank()) {
            Clientes clienteNuevo = new Clientes(codigo, nombre, telefono, correoElectronico);
            usuario.add(clienteNuevo);
            codigo++;
        } else {
            System.out.println("Campos sin rellenar, por favor llenar todos.");
        }
    }
    
    public void mostrarClientes(){
        if(usuario.isEmpty()){
            System.out.println("----No hay usuarios registrados en el sistema----");
        }else{
            System.out.println("====Clientes en el sistema====");
            for(Clientes mostrar : usuario){
                System.out.println("Codigo: " + mostrar.getCodigo() + "\n Nombre: " + mostrar.getNombre() 
                        + "\n Teléfono: " + mostrar.getTelefono() + "\n Correo Electrónico: " + mostrar.getCorreoElectronico()
                        + "\n Fecha de Regitro: " + mostrar.getFechaRegistro()); 
            }
        }
        
    }
}
