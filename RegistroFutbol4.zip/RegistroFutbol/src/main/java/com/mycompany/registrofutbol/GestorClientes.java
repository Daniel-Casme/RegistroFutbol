/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.registrofutbol;

import javax.swing.JOptionPane;

/**
 *
 * @author Daniel CasMe
 */
public class GestorClientes {
    private Clientes[] listaClientes = new Clientes[1000];
    private int contador = 0;
    private int codigo = 1;
    int buscarCodigo;

    public void nuevoUsuario(String nombre, String telefono, String correoElectronico) {
        if (!nombre.isBlank() && !telefono.isBlank()) {

            if (contador >= listaClientes.length) {
                System.out.println("Error: Capacidad maxima de clientes alcanzada.");
                return;
            }

            Clientes clienteNuevo = new Clientes(codigo, nombre, telefono, correoElectronico);

            listaClientes[contador] = clienteNuevo;
            contador++;
            codigo++;

            System.out.println("Cliente registrado con éxito. Código asignado: " + clienteNuevo.getCodigo());
        } else {
            System.out.println("Campos sin rellenar, por favor llenar todos.");
        }
    }

    public void mostrarClientes() {
        if (contador == 0) {
            System.out.println("----No hay usuarios registrados en el sistema----");
        } else {
            System.out.println("====Clientes en el sistema====");
            // Recorremos únicamente hasta 'contador' para no leer posiciones 'null'
            for (int i = 0; i < contador; i++) {
                Clientes mostrar = listaClientes[i];
                System.out.println("Cliente #" + (i+1));
                System.out.println("\nCodigo: " + mostrar.getCodigo()
                        + "\n Nombre: " + mostrar.getNombre()
                        + "\n Teléfono: " + mostrar.getTelefono()
                        + "\n Correo Electrónico: " + mostrar.getCorreoElectronico()
                        + "\n Fecha de Registro: " + mostrar.getFechaRegistro());
            }
        }
    }
    
    private Clientes clienteEncontrado; 

    public void buscarClientePorCodigo(int clienteCodigoBuscar) {
        clienteEncontrado = null; 

        for (int d = 0; d < contador; d++) {
            if (listaClientes[d].getCodigo() == clienteCodigoBuscar) {
                clienteEncontrado = listaClientes[d];
                break;
            }
        }
    }

    public Clientes getClienteEncontrado() {
        return clienteEncontrado;
    }

    public Clientes[] getListaClientes() {
        return listaClientes;
    }

    public int getContador() {
        return contador;
    }
    
    
}
