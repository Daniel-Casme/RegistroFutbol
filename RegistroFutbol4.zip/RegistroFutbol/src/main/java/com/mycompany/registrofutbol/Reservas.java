/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.registrofutbol;
import java.time.LocalTime;
import java.time.LocalDate;
/**
 *
 * @author Daniel CasMe
 */

//Creación, validación, estados, cancelación e historial.
public class Reservas {
    private int idReserva;
    private LocalDate fechaReserva;
    private Clientes cliente;
    private Canchas cancha;
    private LocalTime horaInicio;
    private LocalTime horaFin;
    private String duracion;
    private double montoTotal; // Se agrega para registrar el costo total calculado
    private double anticipo;
    private String estado;

    public Reservas(int idReserva, LocalDate fechaReserva, Clientes cliente, Canchas cancha, 
                    LocalTime horaInicio, LocalTime horaFin, String duracion, 
                    double montoTotal, double anticipo, String estado) {
        
        this.idReserva = idReserva;
        this.fechaReserva = fechaReserva;
        this.cliente = cliente;
        this.cancha = cancha;
        this.horaInicio = horaInicio;
        this.horaFin = horaFin;
        this.duracion = duracion;
        this.montoTotal = montoTotal;
        this.anticipo = anticipo;
        this.estado = estado;
    }

    // --- GETTERS ---
    public int getIdReserva() {
        return idReserva;
    }

    public LocalDate getFechaReserva() {
        return fechaReserva;
    }

    public Clientes getCliente() {
        return cliente;
    }

    public Canchas getCancha() {
        return cancha;
    }

    public LocalTime getHoraInicio() {
        return horaInicio;
    }

    public LocalTime getHoraFin() {
        return horaFin;
    }

    public String getDuracion() {
        return duracion;
    }

    public double getMontoTotal() {
        return montoTotal;
    }

    public double getAnticipo() {
        return anticipo;
    }

    public String getEstado() {
        return estado;
    }

    // --- SETTERS ---
    public void setEstado(String estado) {
        this.estado = estado;
    }

    public void setMontoTotal(double montoTotal) {
        this.montoTotal = montoTotal;
    }
}
