/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.registrofutbol;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 *
 * @author Daniel CasMe
 */
public class GestorReserva {
    private Reservas[] listaReservas = new Reservas[1000];
    private int contador = 0;

    public void guardarReservasLista(int idReserva, LocalDate fechaReserva, Clientes cliente, Canchas cancha, 
                                 LocalTime horaInicio, LocalTime horaFin, 
                                 String duracion, double montoTotal, double anticipo, String estado) {
    
        if (contador >= listaReservas.length) {
            System.out.println("Error: Capacidad máxima alcanzada.");
        } else {
            Reservas reserva = new Reservas(idReserva, fechaReserva, cliente, cancha, 
                                            horaInicio, horaFin, duracion, 
                                            montoTotal, anticipo, estado);

            listaReservas[contador] = reserva;
            contador++;
        }
    }

    public Reservas[] getListaReservas() {
        return listaReservas;
    }

    public int getContador() {
        return contador;
    }
    
}
