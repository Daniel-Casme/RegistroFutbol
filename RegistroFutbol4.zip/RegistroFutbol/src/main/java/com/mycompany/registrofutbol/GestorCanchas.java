/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.registrofutbol;
import java.util.ArrayList;
import java.time.LocalTime;
/**
 *
 * @author Daniel CasMe
 */
public class GestorCanchas {
  private Canchas[] listaCanchas = new Canchas[1000];
    private int contador = 0;
    private Canchas canchaEncontrada;

    public void guardarCancha(String codigo, String nombre, String tipo, 
            int capacidad, int configuracionTarifaria, 
            String estado, LocalTime horaApertura, LocalTime horaCierre){
        
        if(!codigo.isBlank() && !nombre.isBlank() 
                && !tipo.isBlank() && capacidad > 0 
                && configuracionTarifaria > 0 && !estado.isBlank() 
                && horaApertura != null && horaCierre != null && horaApertura.isBefore(horaCierre)){
            
            if (contador >= listaCanchas.length) {
                System.out.println("Error: Capacidad máxima de canchas alcanzada.");
                return;
            }

            Canchas cancha = new Canchas(codigo, nombre, tipo, 
            capacidad, configuracionTarifaria, 
            estado, horaApertura, horaCierre);
            
            listaCanchas[contador] = cancha;
            contador++;
            
        }else{
            System.out.println("Por favor llenar todos los campos.");
        }
    }
    
    public void mostrarCanchas(){
        
        if(contador == 0){
            System.out.println("No se han registrado canchas.");
        }else{
            for(int i = 0; i < contador; i++){
                Canchas mostrar = listaCanchas[i];
                System.out.println("Codigo: " + mostrar.getCodigo() + "\nNombre: " + mostrar.getNombre() 
                    + "\nTipo: " + mostrar.getTipo() + "\nCapacidad: " 
                    + mostrar.getCapacidad() + "\nConfiguracion Tarifaria: " 
                    + mostrar.getConfiguracionTarifaria() + "\nEstado: " + mostrar.getEstado() 
                    + "\nHora de Apertura: " + mostrar.getHoraApertura() 
                    + "\nHora de Cierre: " + mostrar.getHoraCierre());
            }
        }
    }
    
    public void buscarCanchaCodigo(String canchaCodigoBuscar){
        this.canchaEncontrada = null;

        for(int d = 0; d < contador; d++){
            if(listaCanchas[d].getCodigo().equalsIgnoreCase(canchaCodigoBuscar)){
                this.canchaEncontrada = listaCanchas[d];
                break;
            }
        }
    }

    public Canchas getCanchaEncontrada(){
        return canchaEncontrada;
    }

    public Canchas[] getListaCanchas(){
        return listaCanchas;
    }

    public int getContador(){
        return contador;
    }
}
