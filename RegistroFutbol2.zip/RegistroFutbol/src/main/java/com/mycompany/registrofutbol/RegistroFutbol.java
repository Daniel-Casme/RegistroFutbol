/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.registrofutbol;
import java.util.Scanner;
/**
 *
 * @author Daniel CasMe
 */
public class RegistroFutbol {

    public static void main(String[] args) {
        //private String cambioCodigo;
        //private String cambioNombre;
        //private String cambioTipo;
        //private int cambioCapacidad;
        //private int cambioConfiguracionTarifaria;
        //private String cambioEstado;
        //private double cambioHoraApertura;
        //private double cambioHoraCierre;
        
        Scanner sc = new Scanner(System.in);
        GestorClientes main = new GestorClientes();
        
        
        System.out.print("Ingresar Nombre y Apellido: ");
        String nombre = sc.nextLine();

        System.out.print("Ingresar Teléfono (0000-0000): ");
        String telefono = sc.nextLine();

        System.out.print("Ingresar correo electrónico (Enter: opcional): ");
        String correoElectronico = sc.nextLine();
        
        main.nuevoUsuario(nombre, telefono, correoElectronico);
        main.mostrarClientes();
       
    }
}
