/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.registrofutbol;
import java.util.ArrayList;
/**
 *
 * @author Daniel CasMe
 */
public class GestorCanchas {
    ArrayList<Canchas> listaCanchas = new ArrayList<>();
    
    public void guardarCancha(String codigo, String nombre, String tipo, 
            int capacidad, int configuracionTarifaria, 
            String estado, double horaApertura, double horaCierre){
        
        Canchas cancha = new Canchas(codigo, nombre, tipo, 
        capacidad, configuracionTarifaria, 
        estado, horaApertura, horaCierre);
        
        if(!codigo.isBlank() && !nombre.isBlank() 
                && !tipo.isBlank() && capacidad > 0 
                && configuracionTarifaria > 0 && !estado.isBlank() 
                && horaApertura > 0 && horaCierre > 0){
            
            listaCanchas.add(cancha);
        }else{
            System.out.println("Por favor llenar todos los campos.");
        }
    }
    
    public void mostrarCanchas(){
        
        if(listaCanchas.isEmpty()){
            System.out.println("No se han registrado canchas.");
        }else{
            for(Canchas mostrar : listaCanchas ){
                System.out.println("Codigo: " + mostrar.getCodigo() + "\nNombre: " + mostrar.getNombre() 
                    + "\nTipo: " + mostrar.getTipo() + "\nCapacidad: " 
                    + mostrar.getCapacidad() + "\nConfiguracion Tarifaria: " 
                    + mostrar.getConfiguracionTarifaria() + "\nEstado: " + mostrar.getEstado() 
                    + "\nHora de Apertura: " + mostrar.getHoraApertura() 
                    + "\nHora de Cierre: " + mostrar.getHoraCierre());
            }
        }
    }
    
}
